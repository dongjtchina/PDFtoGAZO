﻿using System;

namespace _20200109_デバッガービジュアライザー
{
    public class Class1
    {
    }
}
